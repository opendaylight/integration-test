#ifndef __OPENVSWITCH_VXLANGPE_H
#define __OPENVSWITCH_VXLANGPE_H 1

#include "openvswitch/types.h"

#define u8 uint8_t
#define u32 uint8_t
#define __be32 ovs_be32

/*
 * VXLAN Generic Protocol Extension (VXLAN_F_GPE):
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * |R|R|Ver|I|P|R|O|       Reserved                |Next Protocol  |
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 * |                VXLAN Network Identifier (VNI) |   Reserved    |
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *
 * Ver = Version. Indicates VXLAN GPE protocol version.
 *
 * P = Next Protocol Bit. The P bit is set to indicate that the
 *     Next Protocol field is present.
 *
 * O = OAM Flag Bit. The O bit is set to indicate that the packet
 *     is an OAM packet.
 *
 * Next Protocol = This 8 bit field indicates the protocol header
 * immediately following the VXLAN GPE header.
 *
 * https://tools.ietf.org/html/draft-ietf-nvo3-vxlan-gpe-01
 */

struct vxlanhdr_gpe {
#ifdef WORDS_BIGENDIAN
	u8	reserved_flags2:2,
		version:2,
		instance_applied:1,
		np_applied:1,
		reserved_flags1:1,
		oam_flag:1;
#else
	u8	oam_flag:1,
		reserved_flags1:1,
		np_applied:1,
		instance_applied:1,
		version:2,
		reserved_flags2:2;
#endif
	u8	reserved_flags3;
	u8	reserved_flags4;
	u8	next_protocol;
	__be32	vx_vni;
};

/* VXLAN-GPE header flags. */
#define VXLAN_HF_VER	((1UL <<29) | (1UL <<28))
#define VXLAN_HF_NP	(1UL <<26)
#define VXLAN_HF_OAM	(1UL <<24)

#define VXLAN_GPE_USED_BITS (VXLAN_HF_VER | VXLAN_HF_NP | VXLAN_HF_OAM | \
			     0xff)

/* VXLAN-GPE header Next Protocol. */
#define VXLAN_GPE_NP_IPV4      0x01
#define VXLAN_GPE_NP_IPV6      0x02
#define VXLAN_GPE_NP_ETHERNET  0x03
#define VXLAN_GPE_NP_NSH       0x04

struct vxlan_metadata {
	u32		gbp;
	u32		gpe;
};

#define VXLAN_F_GPE			0x4000
#define VXLAN_HF_GPE 0x04000000

#endif /* __OPENVSWITCH_VXLANGPE_H */
